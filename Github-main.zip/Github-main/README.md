# Github
A MERN based Github replica with custom version control implemented from scratch.
